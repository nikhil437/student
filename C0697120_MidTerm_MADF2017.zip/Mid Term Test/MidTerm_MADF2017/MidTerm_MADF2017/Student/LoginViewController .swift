//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import UIKit

class LoginViewController : UIViewController {
    var Emailid = String()
  var password = String()
    
    @IBOutlet weak var MyEmail: UITextField!
    
    
    @IBOutlet weak var mypassword: UITextField!
    
    
    
    
    @IBOutlet weak var Mylogin: UIButton!
    @IBAction func MyLogin(_ sender: UIButton) {
          if (Emailid == "C0697120") && (password == "Admin123")
          {
            print ("login successsful")
        }
            
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

        func Myloginvalue(_ sender: UITextField) {
       
    }
    
}



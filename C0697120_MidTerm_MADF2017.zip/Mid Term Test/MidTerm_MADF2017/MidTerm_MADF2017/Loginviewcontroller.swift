//
//  Loginviewcontroller.swift
//  MidTerm_MADF2017
//
//  Created by MacStudent on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//

import Foundation
class Login  {
    var Emailid = String()
    var password = String()
    
    
    
    
    
}

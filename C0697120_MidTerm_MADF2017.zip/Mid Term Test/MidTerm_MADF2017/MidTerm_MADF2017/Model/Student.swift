//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import Foundation
class Student
{
    var StudentId = Int()
    var StudentName = CHAR_BIT
    var Email = String()
    var DOB = Date()
    var score =  Int()
    
 if (score>=95)
    {
    print("Your grade is A+")
    }

 else
    if
    ((score >= 85)&&( score <95 ))
    {
    print("Your grade is A");
    }
    if
    ((score >=75 )&&(score<85))
    {
    print("Your grade is B+");
    }
    else
    if
    ((score >=65)&&(score  <75))
    {
    print(" Your grade is B");
    }
    else
    if
    ((score >= 55)&&( score <65 ))
    {
    print("Your grade is C+");
    }
    
    else
    if
    ((score >= 50)&&( score < 55))
    {
    print("Your grade is C");
    }
    
    else
    if
    ((score >= 45)&&( score <50 ))
    {
    print("Your grade is D");
    }
    else
    if
    (score <45 )
    {
    print("FAILED");
    
    

    }
}


